package com.training.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.service.ServiceLayer;

@RestController
public class DemoController {
	
	@Autowired
	ServiceLayer service;

	@GetMapping("/hello")
	public String forEveryOne() {
		String data = service.someBusinessOpAdminCanCall();
		return data + " \n This is data anyone can access!";
	}
	
	@GetMapping("/users/hello")
	public String forUsers() {
		try {
			String data = service.someBusinessOpAdminCanCall();
			return data+" \n This is data that authenticated users can see";
		} catch (Exception e) {
			e.printStackTrace();
			return "access denied";
		}
	}
	
	@GetMapping("/admin/hello")
	public String forAdmin() {
		String data = service.someBusinessOpAdminCanCall();
		return data + " \n This is data that authenticated users can see";
	}
}
