package com.training.service;

public interface ServiceLayer {

	String someBusinessOpAnyoneCanCall();

	String someBusinessOpUserCanCall();

	String someBusinessOpAdminCanCall();

}