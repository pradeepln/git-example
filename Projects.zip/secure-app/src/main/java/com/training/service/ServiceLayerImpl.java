package com.training.service;

import javax.annotation.security.RolesAllowed;

import org.springframework.stereotype.Service;

@Service
public class ServiceLayerImpl implements ServiceLayer {
	
	
	@Override
	public String someBusinessOpAnyoneCanCall() {
		return "Operation that anyone can execute done";
	}
	
	@RolesAllowed("user")
	@Override
	public String someBusinessOpUserCanCall() {
		return "Operation that loggen in user can execute done";
	}
	
	@RolesAllowed("admin")
	@Override
	public String someBusinessOpAdminCanCall() {
		return "Operation that admin can execute done";
	}

}
