package com.training.service;

public interface SMSSender {
	
	public void sendMessage(String message);

}
