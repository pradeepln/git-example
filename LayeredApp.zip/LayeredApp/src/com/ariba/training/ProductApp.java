package com.ariba.training;

import com.ariba.training.ui.ProductConsoleUI;

public class ProductApp {

	public static void main(String[] args) {
		ProductConsoleUI ui = new ProductConsoleUI();
		ui.createProductWithUI();
	}

}
